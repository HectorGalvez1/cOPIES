package fi.dy.masa.litematica.render.infohud;

public enum RenderPhase
{
    PRE,
    POST
}
