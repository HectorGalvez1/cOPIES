package fi.dy.masa.litematica.render.schematic;

public interface IBufferBuilderPatch
{
    void litematica$setOffsetY(float offset);
}
